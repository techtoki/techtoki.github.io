<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script type="text/javascript" src="../js/jquery.js"></script>
    <script type="text/javascript" src="../js/jquery_session.js"></script>
    <script src="https://unpkg.com/@popperjs/core@2"></script>
    <script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../js/cookie.js"></script>
    <script type="module" src="js/index.js"></script>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="index.css">
    <title>TechToki Admin</title>
    
</head>
<style>
    #update-btn{
        font-weight: bolder;
    }
    .modal-title{
        font-weight: bolder;
    }
</style>
<body>
    <header>
        <div class="navbar-sticky">
            <div class="navbar navbar-expand-lg">
                <div class="container">
                    <a href="../index.php" class="navbar-brand  flex-shrink-0">
                        <img src="../assets/images/techtoki_full_logo.svg" width="80" alt="techtoki">
                    </a>
                </div>
            </div>
        </div>
    </header>
    <div id="dashboard_container">
    </div>

</body>
</html>