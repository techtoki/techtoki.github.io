import {Cards} from "../../../tools/product_card/product_card.js";
new Cards({container:document.getElementById("product-container")});