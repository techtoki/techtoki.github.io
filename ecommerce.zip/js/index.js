

$(document).ready(function() {
    //show hide register login and account button
    if(getCookie("user")){
        $("#log-register-btn").remove();
        value = getCookie("user");
        $("#account-a")[0].innerHTML = value.email_address;
    }
    else{
        $("#account-btn").remove();
    }
    // end

    $("#logout-btn").click(function(){
        document.cookie = "user=;expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
        
        $.ajax({
            url: './php/controller/logout_controller.php',
            success: function(data) {
              console.log(data);
            }
        });
        location.reload();
        
    });
    window.addEventListener('scroll', function() {
        if (window.scrollY > 0) {
          document.getElementById('navigation_top').classList.add('fixed-top');
          // add padding top to show content behind navbar
          navbar_height = document.querySelector('.navbar').offsetHeight;
          document.body.style.paddingTop = navbar_height + 'px';
        } else {
          document.getElementById('navigation_top').classList.remove('fixed-top');
           // remove padding top from body
          document.body.style.paddingTop = '0';
        } 
    });

   

});





