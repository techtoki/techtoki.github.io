
<link rel="stylesheet" href="../tools/product_card/product.css">
<?php
    include_once("../../php/managers/product_manager.php");
    $products = "";
   
    if(isset($_POST['product_category'])){
        if($_POST['product_category']!="all"){
            $products = Product::getProductWhere(['category'],$_POST['product_category']);
        }
        else{
            $products = Product::getAllProducts(['category'],$_POST['product_category']);
        }
        foreach($products as $product){
            $discount_price = $product->price-($product->price*($product->discount/100));
            $original_price = "₱".number_format(floatval($product->price), 2);
            $price = "₱".number_format(floatval($discount_price), 2);
            $product_card = <<<EOT
            <div class="card m-2" style="width: 18rem;">
                <img class="card-img-top p-1" src="$product->image_url" alt="Card image cap">
                <div class="card-body d-flex flex-column justify-content-between">
                    <div> 
                        <h5 class="card-title p-0 m-0">$product->name</h5>
                        <p class="card-text description">$product->description</p>
                    </div>
                    <div class="d-flex flex-column W-100"> 
                        <div class="card-text" id="price">$price</div>
                        <div class="card-text">
                            <div class="d-flex">
                                <div id="discount">$original_price </div>
                                <div class="ms-2" id="discount-percent">-$product->discount%</div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <a href="#" class="btn round-0 mt-4 btn-primary w-50 m-2 buy-now" id="buy-now">Buy now</a>
                        <a href="#" class="btn round-0 mt-4 btn-primary w-50 m-2" id="add-cart">Add to cart</a>
                    </div>
                    
                </div>
            </div>
            EOT;
            echo $product_card;
        }
    }
    
    ?>