
export class Cards{
    constructor({category="all",container}){
        this.category = category;
        this.container = container;
        $(document).ready(()=>{
            $.post( "../tools/product_card/product_card.php", { product_category: category})
            .done((data)=>{
                // console.log(this.container);
                $(this.container).load("../tools/product_card/product_card.php",()=>{
                    this.container.innerHTML = data;
                });

            });

        });
    }
}



