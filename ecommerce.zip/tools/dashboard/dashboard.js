

export class Dashboard{
    constructor(tabs,container) {
        this.tabs = tabs;
        this.container = container;
        if(tabs instanceof Array){
            let json_tab = [];
            tabs.forEach((tab)=>{
                if(!tab instanceof Tab){console.log("Needs to be an array instance of Tab and tittle must be unique"); return;}
                json_tab.push({tittle:tab.tittle,subtittle:tab.subtittle,icon:tab.icon,id:tab.id})
            });
            
            $(document).ready(()=>{
                $.post( "../tools/dashboard/dashboard.php", { tabs: json_tab})
                .done(function( data ) {
                    $(container).load("../tools/dashboard/dashboard.php",()=>{
                        container.innerHTML = data;
                        tabs.forEach((tab)=>{
                            $("#"+tab.id).click(()=>{
                                let tabBodyScript = document.createElement("script");
                                let tabContentBody = document.getElementById("tab-body");
                                let tabContentTittle = document.getElementById("tab-tittle");;
                                tabBodyScript.setAttribute("src", tab.scriptPath);
                                tabBodyScript.setAttribute("type", "module");
                                tabContentTittle.appendChild(tabBodyScript);
                                tabContentTittle.childNodes[1].innerHTML = tab.tittle;
                                tabContentTittle.childNodes[3].innerHTML = tab.subtittle;
                                if(tab.phpTabBody!=""){
                                    $(tabContentBody).load(tab.phpTabBody);
                                }
                                
                            });

                        });
                        
                        
                    });
                });
            });
            return;
        }
        console.log("Needs to be an array instance of Tab"); return;
    }
    
}

export class Tab{
    constructor({tittle,subtittle,icon="",scriptPath="",phpTabBody=""}){
        this.tittle = tittle;
        this.subtittle = subtittle;
        this.icon = icon
        this.id="";
        this.scriptPath = scriptPath;
        this.phpTabBody=phpTabBody;
        let words = tittle.toLowerCase().split(" ");
        words.forEach((word)=>{
            this.id+=word;
        });
    }
}
function hasDuplicates(arr) {
    return new Set(arr).size !== arr.length;
}